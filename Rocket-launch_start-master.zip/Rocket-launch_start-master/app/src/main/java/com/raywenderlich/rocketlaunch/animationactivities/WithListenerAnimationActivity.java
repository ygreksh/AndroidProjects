package com.raywenderlich.rocketlaunch.animationactivities;

public class WithListenerAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

package com.raywenderlich.rocketlaunch.animationactivities;

public class FlyThereAndBackAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

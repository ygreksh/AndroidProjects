package com.raywenderlich.rocketlaunch.animationactivities;

public class NoAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {
    // Sorry, no animation here :]
  }
}

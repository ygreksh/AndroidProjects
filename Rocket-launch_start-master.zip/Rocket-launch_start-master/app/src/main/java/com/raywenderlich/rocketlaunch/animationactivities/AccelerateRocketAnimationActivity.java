package com.raywenderlich.rocketlaunch.animationactivities;

public class AccelerateRocketAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

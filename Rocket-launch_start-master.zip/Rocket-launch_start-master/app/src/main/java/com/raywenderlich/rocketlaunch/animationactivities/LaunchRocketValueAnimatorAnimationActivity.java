package com.raywenderlich.rocketlaunch.animationactivities;

public class LaunchRocketValueAnimatorAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

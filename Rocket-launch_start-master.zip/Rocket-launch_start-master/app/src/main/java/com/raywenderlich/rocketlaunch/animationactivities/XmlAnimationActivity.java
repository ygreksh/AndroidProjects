package com.raywenderlich.rocketlaunch.animationactivities;

public class XmlAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

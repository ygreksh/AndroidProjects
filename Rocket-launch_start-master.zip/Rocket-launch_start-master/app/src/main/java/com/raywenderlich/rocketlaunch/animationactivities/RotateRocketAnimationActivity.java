package com.raywenderlich.rocketlaunch.animationactivities;

public class RotateRocketAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

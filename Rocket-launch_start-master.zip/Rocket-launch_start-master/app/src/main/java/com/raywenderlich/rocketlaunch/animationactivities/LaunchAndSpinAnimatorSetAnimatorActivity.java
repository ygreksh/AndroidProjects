package com.raywenderlich.rocketlaunch.animationactivities;

public class LaunchAndSpinAnimatorSetAnimatorActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

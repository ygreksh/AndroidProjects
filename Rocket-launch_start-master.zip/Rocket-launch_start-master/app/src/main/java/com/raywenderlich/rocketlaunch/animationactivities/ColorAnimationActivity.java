package com.raywenderlich.rocketlaunch.animationactivities;

public class ColorAnimationActivity extends BaseAnimationActivity {

  @Override
  protected void onStartAnimation() {

  }
}

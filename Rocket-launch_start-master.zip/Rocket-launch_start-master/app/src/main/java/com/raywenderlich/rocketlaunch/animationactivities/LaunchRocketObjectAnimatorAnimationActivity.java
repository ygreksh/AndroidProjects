package com.raywenderlich.rocketlaunch.animationactivities;

public class LaunchRocketObjectAnimatorAnimationActivity extends BaseAnimationActivity {
  @Override
  protected void onStartAnimation() {

  }
}

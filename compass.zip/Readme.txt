+---------------------------------------------------------------------------+
|                              COMPASS V.2.83                               |
+---------------------------------------------------------------------------+

What is Compass
===============
Compass has been a popular and powerful bookmark manager utility program
since its first release in January, 1997.  It supports three most popular
browsers - Netscape, Internet Explorer, and Opera.  Plus, it can launch any
system specified generic browsers.

What makes Compass unique is the power of handling the hierarchical structure
of folders.  With Compass, you'll be amazed how easily you can find and
organize your bookmarks the way you want, and how easily you can integrate
all bookmarks from different computers or different browsers.

Not only is Compass a bookmark manager, but it is also an "outline editor"
or a "note editor."  You can use Compass to create your personal journal,
notes, outlines, memos, ... etc.  Compass also provides a command to create
"Directory Map" such that you can annotate your local directories and files.
When you use Compass as an outline editor, you will find Compass is even
better than the programs that were created for that purpose.

You can also use Compass as a web page or report generator.  With the power
of Template, you can export your bookmarks or notes in the format you want.
You can even control different folder levels and generate multiple files that
linked back to the main output file.

Compass has a host of useful features to help you manage your bookmarks: find
duplicate bookmarks, find dead links, update redirected URLs, retrieve
keywords and descriptions, powerful logical search, import, export, merge,
sort, create directory map, and more.

Compass can easily handle more than several thousands of bookmarks.  Compass
has been tested and works with Netscape 2.x - 4.x, Microsoft Internet
Explorer 3.x - 5.x and Opera 3.x - 5.x on Windows 95/98/Me/NT4.0/2000.


Brief Features List
===================
1. Handles Netscape, IExplorer, and Opera file format.  Uniform user
   interface for file open, save, import, export, and merge.  All file I/O
   operations are applicable to all three file formats.
2. Unique Tree, List, and Description three-pane layout with two displaying
   styles - Explorer style and Compass style.
3. Export with Template lets you export bookmarks or folders to the format
   you want.  You can edit or create your own Templates.
4. Powerful logical AND, OR, NOT search and intelligent find duplicate URLs.
5. Password protect your bookmark files.
6. Super fast multi-threading generic socket connection to check links,
   retrieve keywords, description and redirected URLs.
7. Powerful multi-selectable Tree pane.
8. Extensive drag & drop - to and from different panes, different instances,
   Compass and browsers, desktop, and Windows Explorer.
9. Communicates with Netscape, IExplorer, and Opera to launch links, add
   new links, open new browsers, replace URLs.
10. Tray icon access.
11. Versatile sorting options.
12. Dynamic Bookmarks menu.


License Agreement
=================
+ This software (Compass 2.x) is SHAREWARE.  You may evaluate this software
  for 50 days without any obligation.  Use after 50 days requires purchasing
  a license.
+ This software is distributed AS IS and without any express or implied
  warranties.
+ The author is not responsible for any damages whatsoever incurred before,
  during, or after the use of this software.
+ This software cannot be resold fo profit without the author expressed
  written permission.
+ This software may be freely distributed, provided that:
  a. Such distribution includes only the original archive.  You may not
     alter, delete, or add any files in the distribution archive.
  b. No money is charged to the person receiving the software, beyond
     reasonable cost of packaging and other overhead.

Single-User License
-------------------
Each Single-User License allows:
The registered user and ONLY the registered user to install and run the
software (Compass 2.x) on any number of workstations.  When the registered
user does not plan to run the software on a workstation, he/she must remove
the software (including the registration file) from the workstation.
A registered user must be a person and can not be a company or an
organization.  The software may not be installed on a server computer.
To install the software on a server computer, you must purchase enough number
of Single-Workstation Licenses (see below) to cover all workstations that
have access to the server.

Single-Workstation License
--------------------------
Each Single-Workstation License allows:
Any number of users to run the software (Compass 2.x) on one and ONLY one
workstation.  The software may be installed only on one workstation.
If the user wants to run the software on another workstation, he/she must
remove the software (including the registration file) from the original
workstation BEFORE he/she installs the software on another workstation.
If the software is to be installed on a server computer, you must purchase
enough number of Single-Workstation Licenses to cover all workstations that
have access to the server.  For example, if there are 10 workstations,
which have access to the server, you need 10 Single-Workstation Licenses
to be able to legally install the software on the server.

Privacy Statement
-----------------
The author respects users' privacy.  Compass does NOT gather any personal
information or web activities.  The author has NO interests in any sort of
personal information or data at all.  However, certain features in Compass
do require the access to the Internet.  Examples are:
a. The Check Links feature (to validate the URLs).
b. The Get Meta Info feature (to retrieve the meta tag information).
c. The Check Updates feature (to see if there are any newer versions).
In the cases that Compass needs to access the Internet, the data needed to
complete the task will be transmitted over the Internet to the server
specified by the task.  No other data will be transmitted, and no other
servers will be connected.  By using this software, the user acknowledges and
agrees such necessary Internet activities.


How to contact the author
=========================
Author: Daniel Liu
Web: http://www.softgauge.com/
Latest version: http://www.softgauge.com/compass/new.htm
Tech support: http://www.softgauge.com/compass/qa.htm
Order: http://www.softgauge.com/compass/order.htm

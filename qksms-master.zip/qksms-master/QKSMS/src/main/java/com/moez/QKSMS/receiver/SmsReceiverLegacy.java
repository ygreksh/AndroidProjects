package com.moez.QKSMS.receiver;

public class SmsReceiverLegacy extends MessagingReceiver {
}

package com.moez.QKSMS.interfaces;

public interface RecipientProvider {
    public String[] getRecipientAddresses();
}

package com.moez.QKSMS.interfaces;

import com.moez.QKSMS.data.Conversation;

public interface ConversationDetails {
    void showDetails(Conversation c);
}
